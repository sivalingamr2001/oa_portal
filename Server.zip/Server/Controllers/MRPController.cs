using Backend.Services;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers;

/// <summary>
/// Handles geographic allocations, customer site roles, address locations, and scheduling parameters.
/// </summary>
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public sealed class MRPController(IMRPService allocationService) : ControllerBase
{
    private readonly IMRPService _allocationService = allocationService;

    [HttpGet("org")]
    public async Task<IActionResult> GetOrganations(CancellationToken cancellationToken)
    {
        var result = await _allocationService.GetInventoryOrganizationsAsync(cancellationToken);
        return Ok(result);
    }

    [HttpGet("headers")]
    public async Task<IActionResult> GetHeaders(int organizationId, string inputItemNo, CancellationToken cancellationToken)
    {
        var result = await _allocationService.GetHeaderAsync(organizationId, inputItemNo, cancellationToken);
        return Ok(result);
    }

    [HttpGet("lines")]
    public async Task<IActionResult> GetLines(
        [FromQuery] int mrpId,
        [FromQuery] int assemblyItemId,
        CancellationToken cancellationToken)
    {
        var lines = await _allocationService.GetLinesAsync(mrpId, assemblyItemId, cancellationToken);

        return Ok(lines);
    }
}