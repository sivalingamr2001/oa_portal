﻿namespace Backend.Shared;

/// <summary>
/// Provides centralized SQL query constants used throughout the application.
/// </summary>
public static class Queries
{
    /// <summary>
    /// Retrieves a specific inventory organization definition by its Organization ID.
    /// </summary>
    public const string GetInventoryOrganizationById = @"
        SELECT ORGANIZATION_ID AS ""OrganizationId"", ORGANIZATION_CODE AS ""OrganizationCode"" 
        FROM ORG_ORGANIZATION_DEFINITIONS
        WHERE ORGANIZATION_ID IN (SELECT DISTINCT ORGANIZATION_ID FROM jan_mrp_master_lines)";

    public const string GetHeaderDetails = @"
        select DISTINCT MRP_ID, CREATION_DATE, SCHEDULE_DESIGNATOR, 
        COMPILE_DESIGNATOR, INPUT_ITEM_NO, ASSEMBLY_ITEM_ID
        from jan_mrp_full_pegging_tab WHERE ORGANIZATION_ID = :OrganizationId AND INPUT_ITEM_NO = :InputItemNo
        ORDER BY CREATION_DATE DESC";

    public const string GetLinesByHeaderId = @"
        select COMPONENT_NO, jan_itemdesc(COMPONENT_NO) as COMPONENT_DESC,SUM(ALLOCATED_QTY) as ALLOCATED_QTY, DEMAND_DATE,
        SUPPLY_DATE,MAKE_BUY,NEW_ITEM_TYPE,OS_TAG,OPTIMUM_QTY, CUSTODIAN_NAME 
        FROM  jan_mrp_full_pegging_tab 
        WHERE MRP_ID = :MrpId
        AND ASSEMBLY_ITEM_ID = :AssemblyItemId
        GROUP BY COMPONENT_NO, DEMAND_DATE, SUPPLY_DATE,MAKE_BUY,NEW_ITEM_TYPE,OS_TAG,OPTIMUM_QTY, CUSTODIAN_NAME
        ORDER BY COMPONENT_NO";
}
