﻿namespace Backend.Models;

public class MrpLineDto
{
    public string? COMPONENT_NO { get; set; }
    public string? COMPONENT_DESC { get; set; }
    public decimal? ALLOCATED_QTY { get; set; }
    public DateTime? DEMAND_DATE { get; set; }
    public DateTime? SUPPLY_DATE { get; set; }
    public string? MAKE_BUY { get; set; }
    public string? NEW_ITEM_TYPE { get; set; }
    public string? OS_TAG { get; set; }
    public decimal? OPTIMUM_QTY { get; set; }
    public string? CUSTODIAN_NAME { get; set; }
}
