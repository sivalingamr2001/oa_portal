﻿using Backend.Models;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Services;

/// <summary>
/// Service contract handling geographic allocations, customer site uses, operational address data, and scheduling.
/// </summary>
public interface IMRPService
{
    Task<IEnumerable<dynamic>> GetInventoryOrganizationsAsync(CancellationToken cancellationToken = default);
    Task<IEnumerable<dynamic>> GetHeaderAsync(int organizationId, string inputItemNo, CancellationToken cancellationToken = default);
    Task<IEnumerable<MrpLineDto>> GetLinesAsync(int mrpId, int assemblyItemId, CancellationToken cancellationToken = default);
}
