﻿using Backend.Models;
using Backend.Shared;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Services;

/// <summary>
/// Implements the allocation service layer using dynamic query execution with parameterised bindings.
/// </summary>
public sealed class MRPService(IDynamicQueryExecutor dynamicQuery) : IMRPService
{
    private readonly IDynamicQueryExecutor _queryExecutor = dynamicQuery;

    public Task<IEnumerable<dynamic>> GetInventoryOrganizationsAsync(CancellationToken cancellationToken = default)
         => _queryExecutor.QueryAsync<dynamic>(
            Queries.GetInventoryOrganizationById,
            cancellationToken: cancellationToken);

    public Task<IEnumerable<dynamic>> GetHeaderAsync(int organizationId, string inputItemNo, CancellationToken cancellationToken = default)
        => _queryExecutor.QueryAsync<dynamic>(
            Queries.GetHeaderDetails,
            new { OrganizationId = organizationId, InputItemNo = inputItemNo },
            cancellationToken: cancellationToken);

    public Task<IEnumerable<MrpLineDto>> GetLinesAsync(int mrpId, int assemblyItemId, CancellationToken cancellationToken = default)
        => _queryExecutor.QueryAsync<MrpLineDto>(
            Queries.GetLinesByHeaderId,
            new { MrpId = mrpId, AssemblyItemId = assemblyItemId },
            cancellationToken: cancellationToken);
}
